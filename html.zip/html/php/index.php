<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}

// 세션에 username이 설정되어 있는지 확인
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // 세션이 없을 경우 로그인 페이지로 리다이렉트
    exit();
}

$username = htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Website</title>
</head>
<body>
    <h1>Welcome, <?php echo $username; ?>!</h1>
    <a href="logout.php">Logout</a>
    <br>
    <a href="qa_board.php">Go to Q&A Board</a>
    <a href="search.php">Go to Search Page</a>

</body>
</html>

