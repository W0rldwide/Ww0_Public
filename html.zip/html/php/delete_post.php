<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}

$conn = new mysqli("localhost", "user", "user", "mywebsite");

$post_id = $_GET['id'];

// 게시글에 첨부된 파일이 있으면 삭제
$result = $conn->query("SELECT file_path FROM posts WHERE id='$post_id'");
$post = $result->fetch_assoc();
if (!empty($post['file_path'])) {
    unlink($post['file_path']); // 파일 삭제
}

// 게시글 삭제
$conn->query("DELETE FROM posts WHERE id='$post_id'");

header("Location: qa_board.php"); // 삭제 후 Q&A 보드로 리다이렉트
exit();

