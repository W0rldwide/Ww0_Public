<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}

$conn = new mysqli("localhost", "user", "user", "mywebsite");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// GET 요청으로부터 post_id 값을 가져옴
$post_id = isset($_GET['post']) ? $_GET['post'] : 0;
$query = "SELECT * FROM posts WHERE id = $post_id";

$result = $conn->query($query);
if (!$result) {
    die("Error in query execution: " . $conn->error);
}

if ($result->num_rows == 0) {
    echo json_encode(['error' => 'No data found']);
    exit;
}

// 결과 가져오기
$post = $result->fetch_assoc();

// 결과를 JSON으로 반환
echo json_encode([
    'title' => $post['title'],
    'created_at' => $post['created_at'],
    'content' => $post['content'],
    'attachments' => $post['attachments']
]);
?>

