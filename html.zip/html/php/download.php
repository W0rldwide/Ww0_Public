<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}


// 오류 출력 활성화
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 세션 확인
if (!isset($_SESSION['username'])) {
    exit("You need to log in to download files.");
}

// 데이터베이스 연결
$conn = new mysqli("localhost", "user", "user", "mywebsite");
if ($conn->connect_error) {
    exit("Connection failed: " . $conn->connect_error);
}

// id 파라미터 확인 및 가져오기
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $file_id = $_GET['id'];
} else {
    exit("Invalid post ID.");
}

// 게시물을 조회하여 파일 정보 가져오기
$result = $conn->query("SELECT file_path FROM posts WHERE id='$file_id'");
if (!$result || $result->num_rows === 0) {
    exit("Invalid post ID or no file attached.");
}

$post = $result->fetch_assoc();
$file_path = $post['file_path'];

// 파일 경로가 비어 있는지 확인
if (empty($file_path)) {
    exit("No file attached to this post.");
}

// 파일 존재 여부 확인 후 다운로드 처리
if (file_exists($file_path)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Content-Length: ' . filesize($file_path));
    readfile($file_path); // 파일 내용을 출력하여 다운로드
    exit();
} else {
    exit("File does not exist.");
}
?>

