<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}

$query = isset($_GET['query']) ? $_GET['query'] : '';

if (!empty($query)) {
    // 결과 출력 (원하는 형태로 이곳에서 처리)
    echo "Search query: " . $query; // 필터링 없이 그대로 출력
} else {
    echo "No results found.";
}
?>

