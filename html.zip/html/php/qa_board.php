<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}



$conn = new mysqli("localhost", "user", "user", "mywebsite");

if ($conn->connect_error) {
    // DB 연결 실패 시 메시지 반환
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5; 
$offset = ($page - 1) * $limit;

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT id, title FROM posts 
        WHERE title LIKE '%$search_query%' OR content LIKE '%$search_query%' 
        LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

if (!$result) {
    // 쿼리 실행 실패 시 메시지 반환
    echo json_encode(['error' => 'Query execution failed']);
    exit();
}

$total_sql = "SELECT COUNT(*) as total FROM posts WHERE title LIKE '%$search_query%' OR content LIKE '%$search_query%'";
$total_result = $conn->query($total_sql);
if (!$total_result) {
    // 총 게시물 수 쿼리 실패 시 메시지 반환
    echo json_encode(['error' => 'Failed to retrieve total post count']);
    exit();
}

$total_row = $total_result->fetch_assoc();
$total_posts = $total_row['total'];
$total_pages = max(ceil($total_posts / $limit), 1);

$posts = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
    }
}

// 결과 반환
echo json_encode([
    'posts' => $posts,
    'total_pages' => $total_pages
]);

$conn->close();
?>
