<?php
session_start();
$conn = new mysqli("localhost", "user", "user", "mywebsite");

// DB 연결 오류 처리
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 취약한 쿼리 (SQL 인젝션이 가능)
    $result = $conn->query("SELECT * FROM users WHERE username='$username' AND password='$password'");
    $user = $result->fetch_assoc();

    if ($user) {
        // 로그인 성공
        $_SESSION['username'] = $username;
        echo json_encode(['success' => true]);
        exit();
    } else {
        // 로그인 실패
        echo json_encode(['error' => 'Invalid credentials']);
        exit();
    }
}

echo json_encode(['error' => 'Invalid request']);

