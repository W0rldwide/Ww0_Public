<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.html"); 
    exit();
}

// 오류 출력 활성화
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 세션 확인
if (!isset($_SESSION['username'])) {
    echo json_encode(['error' => 'You need to log in to post.']);
    exit();
}

// 데이터베이스 연결
$conn = new mysqli("localhost", "user", "user", "mywebsite");
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed.']);
    exit();
}

// 제목과 내용 유효성 검사
$title = isset($_POST['title']) ? $conn->real_escape_string($_POST['title']) : '';
$content = isset($_POST['content']) ? $conn->real_escape_string($_POST['content']) : '';
$username = $_SESSION['username'];
$is_private = isset($_POST['private']) ? 1 : 0; // private 체크 여부

if (empty($title) || empty($content)) {
    echo json_encode(['error' => 'Title and content are required.']);
    exit();
}

// 사용자 ID 가져오기
$user_result = $conn->query("SELECT id FROM users WHERE username='$username'");
if (!$user_result || $user_result->num_rows === 0) {
    echo json_encode(['error' => 'User not found.']);
    exit();
}

$user = $user_result->fetch_assoc();
$file_path = '';
$file_name = '';

// 파일 업로드 처리
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $file_name = basename($_FILES['attachment']['name']);
    $file_name = preg_replace("/[^a-zA-Z0-9\.\-_]/", '', $file_name); // 파일명 정리
    $file_path = 'uploads/' . $file_name;

    if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $file_path)) {
        echo json_encode(['error' => 'File upload failed.']);
        exit();
    }
}

// 게시글 삽입 쿼리 (파일 경로 및 비공개 여부 포함)
$insert_query = "INSERT INTO posts (user_id, title, content, file_path, file_name, locked) 
                 VALUES ('{$user['id']}', '$title', '$content', '$file_path', '$file_name', '$is_private')";

// 쿼리 실행
if ($conn->query($insert_query)) {
    echo json_encode(['success' => 'Post created successfully!']);
} else {
    echo json_encode(['error' => 'Failed to create post: ' . $conn->error]);
}

// 연결 종료
$conn->close();
?>

